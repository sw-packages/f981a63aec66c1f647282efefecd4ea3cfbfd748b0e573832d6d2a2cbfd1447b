//
// detail/reactive_socket_sendmmsg_op.hpp
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//
// Copyright (c) 2003-2026 Christopher M. Kohlhoff (chris at kohlhoff dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#ifndef ASIO_DETAIL_REACTIVE_SOCKET_SENDMMSG_OP_HPP
#define ASIO_DETAIL_REACTIVE_SOCKET_SENDMMSG_OP_HPP

#if defined(_MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif // defined(_MSC_VER) && (_MSC_VER >= 1200)

#include "asio/detail/config.hpp"

#if !defined(ASIO_HAS_IOCP) \
  && !defined(ASIO_WINDOWS_RUNTIME)

#include "asio/detail/bind_handler.hpp"
#include "asio/detail/buffer_sequences_adapter.hpp"
#include "asio/detail/empty_range.hpp"
#include "asio/detail/fenced_block.hpp"
#include "asio/detail/handler_alloc_helpers.hpp"
#include "asio/detail/handler_work.hpp"
#include "asio/detail/memory.hpp"
#include "asio/detail/reactor_op.hpp"
#include "asio/detail/socket_ops.hpp"

#include "asio/detail/push_options.hpp"

namespace asio {
ASIO_INLINE_NAMESPACE_BEGIN
namespace detail {

template <typename BufferSequences,
    typename EndpointSequence = empty_range, typename Endpoint = void>
class reactive_socket_sendmmsg_op_base : public reactor_op
{
public:
  template <typename B, typename E>
  reactive_socket_sendmmsg_op_base(const asio::error_code& success_ec,
      socket_type socket, B&& buffer_sequences, E&& endpoints,
      socket_base::message_flags flags, func_type complete_func)
    : reactor_op(success_ec, &reactive_socket_sendmmsg_op_base::do_perform,
          complete_func),
      socket_(socket),
      buffer_sequences_(static_cast<B&&>(buffer_sequences)),
      endpoints_(static_cast<E&&>(endpoints)),
      flags_(flags)
  {
  }

  static ASIO_ALWAYS_INLINE status do_perform(reactor_op* base)
  {
    ASIO_ASSUME(base != 0);
    reactive_socket_sendmmsg_op_base* o(
        static_cast<reactive_socket_sendmmsg_op_base*>(base));

    status result = non_blocking_send_multiple<Endpoint>(o->socket_,
        o->buffer_sequences_, o->endpoints_, o->flags_, o->ec_,
        o->bytes_transferred_) ? done : not_done;

    ASIO_HANDLER_REACTOR_OPERATION((*o, "non_blocking_sendmmsg",
          o->ec_, o->bytes_transferred_));

    return result;
  }

private:
  socket_type socket_;
  BufferSequences buffer_sequences_;
  EndpointSequence endpoints_;
  socket_base::message_flags flags_;
};

template <typename BufferSequences, typename EndpointSequence,
    typename Endpoint, typename Handler, typename IoExecutor>
class reactive_socket_sendmmsg_op
  : public reactive_socket_sendmmsg_op_base<
      BufferSequences, EndpointSequence, Endpoint>
{
public:
  typedef Handler handler_type;
  typedef IoExecutor io_executor_type;

  ASIO_DEFINE_HANDLER_PTR(reactive_socket_sendmmsg_op);

  template <typename B, typename E>
  reactive_socket_sendmmsg_op(const asio::error_code& success_ec,
      socket_type socket, B&& buffer_sequences, E&& endpoints,
      socket_base::message_flags flags, Handler& handler,
      const IoExecutor& io_ex)
    : reactive_socket_sendmmsg_op_base<
        BufferSequences, EndpointSequence, Endpoint>(
          success_ec, socket, static_cast<B&&>(buffer_sequences),
          static_cast<E&&>(endpoints), flags,
          &reactive_socket_sendmmsg_op::do_complete),
      handler_(static_cast<Handler&&>(handler)),
      work_(handler_, io_ex)
  {
  }

  static void do_complete(void* owner, operation* base,
      int /*error_value*/, std::size_t /*bytes_transferred*/)
  {
    // Take ownership of the handler object.
    ASIO_ASSUME(base != 0);
    reactive_socket_sendmmsg_op* o(
        static_cast<reactive_socket_sendmmsg_op*>(base));
    ptr p = { asio::detail::addressof(o->handler_), o, o };

    ASIO_HANDLER_COMPLETION((*o));

    // Take ownership of the operation's outstanding work.
    handler_work<Handler, IoExecutor> w(
        static_cast<handler_work<Handler, IoExecutor>&&>(o->work_));

    ASIO_ERROR_LOCATION(o->ec_);

    // Make a copy of the handler so that the memory can be deallocated before
    // the upcall is made. Even if we're not about to make an upcall, a
    // sub-object of the handler may be the true owner of the memory associated
    // with the handler. Consequently, a local copy of the handler is required
    // to ensure that any owning sub-object remains valid until after we have
    // deallocated the memory here.
    detail::binder2<Handler, asio::error_code, std::size_t>
      handler(o->handler_, o->ec_, o->bytes_transferred_);
    p.h = asio::detail::addressof(handler.handler_);
    p.reset();

    // Make the upcall if required.
    if (owner)
    {
      fenced_block b(fenced_block::half);
      ASIO_HANDLER_INVOCATION_BEGIN((handler.arg1_, handler.arg2_));
      w.complete(handler, handler.handler_);
      ASIO_HANDLER_INVOCATION_END;
    }
  }

  static void do_immediate(operation* base, bool, const void* io_ex)
  {
    // Take ownership of the handler object.
    ASIO_ASSUME(base != 0);
    reactive_socket_sendmmsg_op* o(
        static_cast<reactive_socket_sendmmsg_op*>(base));
    ptr p = { asio::detail::addressof(o->handler_), o, o };

    ASIO_HANDLER_COMPLETION((*o));

    // Take ownership of the operation's outstanding work.
    immediate_handler_work<Handler, IoExecutor> w(
        static_cast<handler_work<Handler, IoExecutor>&&>(o->work_));

    ASIO_ERROR_LOCATION(o->ec_);

    // Make a copy of the handler so that the memory can be deallocated before
    // the upcall is made. Even if we're not about to make an upcall, a
    // sub-object of the handler may be the true owner of the memory associated
    // with the handler. Consequently, a local copy of the handler is required
    // to ensure that any owning sub-object remains valid until after we have
    // deallocated the memory here.
    detail::binder2<Handler, asio::error_code, std::size_t>
      handler(o->handler_, o->ec_, o->bytes_transferred_);
    p.h = asio::detail::addressof(handler.handler_);
    p.reset();

    ASIO_HANDLER_INVOCATION_BEGIN((handler.arg1_, handler.arg2_));
    w.complete(handler, handler.handler_, io_ex);
    ASIO_HANDLER_INVOCATION_END;
  }

private:
  Handler handler_;
  handler_work<Handler, IoExecutor> work_;
};

} // namespace detail
ASIO_INLINE_NAMESPACE_END
} // namespace asio

#include "asio/detail/pop_options.hpp"

#endif // !defined(ASIO_HAS_IOCP) && !defined(ASIO_WINDOWS_RUNTIME)

#endif // ASIO_DETAIL_REACTIVE_SOCKET_SENDMMSG_OP_HPP
