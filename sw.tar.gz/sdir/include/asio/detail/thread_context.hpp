//
// detail/thread_context.hpp
// ~~~~~~~~~~~~~~~~~~~~~~~~~
//
// Copyright (c) 2003-2026 Christopher M. Kohlhoff (chris at kohlhoff dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#ifndef ASIO_DETAIL_THREAD_CONTEXT_HPP
#define ASIO_DETAIL_THREAD_CONTEXT_HPP

#if defined(_MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif // defined(_MSC_VER) && (_MSC_VER >= 1200)

#include <climits>
#include <cstddef>
// Needs thread_info_base's full definition for call_stack<thread_info_base>
// below (key_type/key(), and the static_cast in top()/contains()).
#include "asio/detail/thread_info_base.hpp"

#include "asio/detail/push_options.hpp"

namespace asio {
ASIO_INLINE_NAMESPACE_BEGIN
namespace detail {

// Base class for things that manage threads (scheduler, win_iocp_io_context).
class thread_context
{
public:
  // Obtain a pointer to the top of the thread call stack. Returns null when
  // not running inside a thread context.
  ASIO_DECL static thread_info_base* top_of_thread_call_stack();

protected:
  // Per-thread call stack to track the state of each thread in the context.
  typedef call_stack<thread_info_base> thread_call_stack;
};

} // namespace detail
ASIO_INLINE_NAMESPACE_END
} // namespace asio

#include "asio/detail/pop_options.hpp"

#if defined(ASIO_HEADER_ONLY)
# include "asio/detail/impl/thread_context.ipp"
#endif // defined(ASIO_HEADER_ONLY)

#endif // ASIO_DETAIL_THREAD_CONTEXT_HPP
